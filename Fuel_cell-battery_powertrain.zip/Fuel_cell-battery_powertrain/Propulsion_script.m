
clearvars
close all
clc

%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%  Callback Funcions  %%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

addpath(genpath('Callback Functions'));

run('Gas_properties.m');
run('Coolant_properties.m');
load('Propeller LUT.mat')



%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%  Fuel Cell  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

% MEA
G_H2O = -237140;                                                            % [J/mol] Reaction Gibbs energy
E_cell = G_H2O /(-2 * F);                                                   % [V] Reaction standard potential
HHV_H2 = 285800;                                                            % [J/mol]  Higher heating value of hydrogen
N_cell = 400;                                                               % [-] N. of cell
t_membrane = 0.0125;                                                        % [cm] Membrane thickness
rho_membrane = 2000;                                                        % [kg/m^3] Density of dry membrane
K_darcy = 1.58 * 10^(-14);                                                  % [cm^2] Darcy's contant
MM_membrane_dry = 1.1;                                                      % [kg/mol] Equivalent weight of dry membrane
t_gdl_A = 250;                                                              % [um] Anode gas diffusion layer (GDL) thickness
t_gdl_C = 250;                                                              % [um] Cathode gas diffusion layer (GDL) thickness
D_H2O_gdl_A = 0.07;                                                         % [cm^2/s] Water vapor diffusivity in anode GDL
D_H2O_gdl_C = 0.07;                                                         % [cm^2/s] Water vapor diffusivity in cathode GDL
alpha = 0.7;                                                                % [-] Tafel eq. coefficient Charge transfer coefficient
area_cell = 280;                                                            % [cm^2] Fuel cell area
io = 1e-04;                                                                 % [A/cm^2] Exchange current density
iL = 1.4;                                                                   % [A/cm^2] Limiting current density
I_FC_max=350;                                                               % [A] Maximum fuel cell current 
mea_rho = 1800;                                                             % [kg/m^3] Overall density of membrane electrode assembly
mea_cp = 870;                                                               % [J/(kg*K)] Overall specific heat of membrane electrode assembly
mea_mass = N_cell * mea_rho * area_cell * 10^(-4)* ...
          (t_membrane * 10^(-2) + (t_gdl_C + t_gdl_A) * 10^(-6));           % [kg] Overall stack mass 



%%%  Auxiliary systems  %%%


% HYDROGEN SOURCE

%Hydrogen tank
tank_p = 70;                                                                % [MPa] Fuel tank pressure
tank_T_start = 20 + 273.15;                                                 % [K] Initial tank temperature
tank_yH2 = 1 - 3e-4;                                                        % [-] Hydrogen mole fraction
tank_xH2 = tank_yH2;
V_tank = 0.12;                                                              % [m^3] Tank volume
m_H2_start = tank_p * 10^6 * V_tank / R_H2 / tank_T_start;                  % [kg] Initial tank hydrogen mass
D_tank = 0.01;                                                              % [m] Pipe diameter
S_tank = pi * D_tank^2 / 4;                                                 % [m^2] Cross-sectional area of the outlet

%Hydrogen valve
D_hv = D_tank;                                                              % [m] Valve pipe diameter
S_hv = pi * D_hv^2 / 4;                                                     % [m^2] Cross sectional area
Cd_hv = 0.64;                                                               % [-] Discharge coefficient
p_set_a = 161325;                                                           % [Pa] Anode networks setpoint pressure
r_min_hv = 1e-4;
r_max_hv = 1;
A_min_hv = pi * (r_min_hv * D_hv)^2 / 4;                                    % [m^2] Min valve opening area
A_max_hv = pi * (r_max_hv * D_hv)^2 / 4;                                    % [m^2] Max valve opening area
p_range_hv = 0.005;                                                         % [MPa]
k_v = 2.1e-7;                                                               % [kg/(Pa*s)] Outlet flow contant


% RECIRCULATION

volume_r = 0.05^3;                                                          % [m^3] Pipe volume 
anode_tube_D_r = 0.01;                                                      % [m] Pipe diameter
area_r = pi * anode_tube_D_r^2 / 4;                                         % [m^2] Cross-sectional area of the pipe
k_r = 4e-5;                                                                 % [kg/(Pa*s)] Outlet flow contant

% ANODE HUMIDIFICATION

anode_tube_D_ha = 0.05;                                                     % [m] Pipe diameter[m]
area_ha = pi * anode_tube_D_ha^2 /4;                                        % [m^2] Cross-sectional area of the pipe
length_ha = 0.25;                                                           % [m] Pipe length
volume_ha = area_ha * length_ha;                                            % [m^3] Pipe volume
RH_set_a = 1;                                                               % [-] Relative humidity setpoint
k_ha = 6e-5;                                                                % [kg/(Pa*s)] Outlet flow contant
kp_ha=0.1;                                                                  % [kg/s] Proportional gain humidification control


% ANODE GAS CHANNELS

channels_width_a = 0.01;                                                    % [m] Gas channel width/height
Dh_a = channels_width_a;                                                    % [m] Hydraulic diameter
N_channels_a = 8;                                                           % [-] Number of gas channels per cell
area_a = channels_width_a^2 * N_channels_a * N_cell;                        % [m^2] Cross-sectional area of the pipe
length_a = 10^(-2) * sqrt(area_cell);                                       % [m] Pipe length
Nu_lam_a = 3.66;                                                            % [-] Nusselt number for laminar flow heat transfer
roughness_a = 15e-6;                                                        % [m] Internal surface absolute roughness 
volume_a = area_a * length_a;                                               % [m^3] Pipe volume
surface_area_a = (4 * area_a / Dh_a) * length_a;                            % [m^2] Pipe surface area
kp_r= 0.8 / (iL * area_cell);                                               % [1/A] Proportional gain recirculation control
c_r = 0.2;                                                                  % [-] Recirculation control constant
kp2_r = 0.01;                                                               % [kg/s] Recirculation control proportional gain

% OXYGEN SOURCE

%Compressor 
cathode_tube_D_comp = 0.05;                                                 % [m] Cathode tube diameter
S_comp_in = pi * cathode_tube_D_comp^2 / 4;                                 % [m^2] Compressor inlet cross sectional area 
S_comp_out = S_comp_in;                                                     % [m^2] Compressor outlet cross sectional area 
volume_comp = 0.0003;                                                       % [m^3] Chamber volume 
k_comp = 4e-3;                                                              % [kg/(Pa*s)] Outlet flow contant
k_P_cp=5;                                                                   % [(s/kg)] Proportional control gain
k_I_cp=0.5;                                                                 % [1/kg] Integral control gain

% Compressor map
comp_p_ratio_TLU = [1; 1.25; 1.5; 1.75; 2];                                 % [-] Pressure ratio vector
comp_rpm_TLU = [0, 1800, 3600];                                             % [rpm] Shaft speed vector
comp_mdot_corr_TLU = [ 0 0.05 0.1 ; 0 0.0375 0.075 ; 0 0.025 0.05 ;
                      0 0.0125 0.025 ; 0 0 0 ] * 4;                         % [kg/s] Corrected mass flow rate table


% CATHODE HUMIDIFICATION

cathode_tube_D_hc = 0.05;                                                   % [m] Pipe diameter
area_hc = pi * cathode_tube_D_hc^2 /4;                                      % [m^2] Cross-sectional area of the pipe
length_hc = 0.25;                                                           % [m] pipe length
volume_hc = area_hc * length_hc;                                            % [m^3] Pipe volume
RH_set_c = 1;                                                               % [-] Relative humidity setpoint
k_hc = 4e-3;                                                                % [kg/(Pa*s)] Outlet flow contant
kp_hc=0.1;                                                                  % [kg/s] Proportional gain humidification control


% CATHODE GAS CHANNELS

channels_width_c = 0.01;                                                    % [m] Gas channel width/height
N_channels_c = 8;                                                           % [-] Number of gas channels per cell
area_c = channels_width_c^2 * N_channels_c * N_cell;                        % [m^2] Cross-sectional area of the pipe
length_c = 10^(-2) * sqrt(area_cell);                                       % [m] Pipe length
Dh_c = channels_width_c;                                                    % [m] Hydraulic diameter
roughness_c = 15e-6;                                                        % [m] Internal surface absolute roughness 
Nu_lam_c = 3.66;                                                            % [-] Nusselt number for laminar flow heat transfer
surface_area_c = (4 * area_c / Dh_c) * length_c;                            % [m^2] Pipe surface area
volume_c = area_c * length_c;                                               % [m^3] Pipe volume
k_c = 4e-3;                                                                 % [kg/(Pa*s)] Outlet flow contant


% CATHODE EXHAUST

cathode_tube_D_cex = 0.05;                                                  % [m] Pipe diameter
S_cex=pi * cathode_tube_D_cex^2 / 4;                                        % [m^2] Cross-sectional area of the pipe
Cd_cex = 0.64;                                                              % [-] Discharge coefficient
r_min_cex = 1e-4;
r_max_cex = 0.8;
A_min_cex = pi * (r_min_cex * cathode_tube_D_cex)^2 / 4;                    % [m^2] Min valve opening area
A_max_cex = pi * (r_max_cex * cathode_tube_D_cex)^2 / 4;                    % [m^2] Max valve opening area
p_range_cex = 0.005;                                                        % [MPa]
p_set_c = 161325;                                                           % [Pa] Cathode networks setpoint pressure


% CONDENSATION

tau_cond = 1e-3;                                                            % [s] Condensation time constant
RH_sat = 1;                                                                 % [-] Relative humidity at saturation


% COOLING SYSTEM

%FC Coolant channels 
channels_width_cool = 0.01;                                                 % [m] Coolant channel width/height
N_passes_cool = 12;                                                         % [-] Number of coolant channel passes per layer
N_layers_cool = 20;                                                         % [-] Number of coolant layers in stack
coolant_tube_D = 0.05;                                                      % [m] Coolant tube diameter
length_cool = 10^(-2) * sqrt(area_cell) * N_passes_cool;                    % [m] Pipe length 
area_cool = channels_width_cool^2 * N_layers_cool;                          % [m^2] Cross-sectional area
Dh_cool = channels_width_cool;                                              % [m] Hydraulic diameter
roughness_cool = 15e-6;                                                     % [m] Internal surface absolute roughness [m]
Re_lam = 2000;                                                              % [-] Laminar flow upper Reynolds number limit
Re_tur = 4000;                                                              % [-] Turbulent flow lower Reynolds number limit
Nu_lam_cool = 3.66;                                                         % [-] Nusselt number for laminar flow heat transfer
surface_area_cool = (4 * area_cool / Dh_cool) * length_cool;                % [m^2] Pipe surface area
volume_cool = area_cool * length_cool;                                      % [m^3] Pipe volume
k_cc = 1e-4;                                                                % [kg/(Pa*s)] Outlet flow contant

%Coolant tank
x_in = 0.08;                                                                % [m] Initial displacement 
A_ct = 0.1;                                                                 % [m^2] Cross-sectional area 
dead_volume = A_ct * 0.001;                                                 % [m^3] Death volume
p_tank_cool = 101325;                                                       % [MPa] Pressure of coolant tank
V_tank_cool_0 = dead_volume + A_ct * x_in;                                  % [m^3] Initial coolant tank volume

%Coolant pump
k_P_p=0.2;                                                                  % [kg/(s°C)] Coolant tank proportional control gain
k_I_p=0.01;                                                                 % [kg/(s^2°C)] Coolant tank integral control gain 
T_FC_ref=80;                                                                % [°C] FC reference temperature


% Radiator 
L_rad = 1;                                                                  % [m] Overall radiator length
W_rad = 0.025;                                                              % [m] Overall radiator width 
H_rad = 0.5;                                                                % [m] Overal radiator height
N_tubes_rad = 25;                                                           % [-] Number of coolant tubes
H_tube_rad = 0.0015;                                                        % [m] Height of each coolant tube 
fin_spacing_rad = 0.002;                                                    % [-] Fin spacing
eta_fin_rad = 0.7;                                                          % [-] Fin efficiency
t_wall_rad = 1e-4;                                                          % [m] Material thickness
H_gap_rad = (H_rad - N_tubes_rad*H_tube_rad) / (N_tubes_rad - 1);           % [m] Height between coolant tubes
air_primary_area_rad = 2 * (N_tubes_rad - 1) * W_rad * (L_rad + H_gap_rad); % [m^2] Primary air heat transfer surface area
N_fins_rad = (N_tubes_rad - 1) * L_rad / fin_spacing_rad;                   % [-] Total number of fins
air_area_fins_rad = 2 * N_fins_rad * W_rad * H_gap_rad;                     % [m^2] Total fin surface area
roughness_rad = 15e-6;                                                      % [m] Internal surface absolute roughness 
Re_lam = 2000;                                                              % [-] Laminar flow upper Reynolds number limit
Re_tur = 4000;                                                              % [-] Turbulent flow lower Reynolds number limit
Nu_lam_rad = 3.66;                                                          % [-] Nusselt number for laminar flow heat transfer
Dh_rad= 2 * W_rad * H_tube_rad / (W_rad + H_tube_rad);                      % [m] Hydraulic diameter [m]
area_rad = W_rad * H_tube_rad * N_tubes_rad;                                % [m^2] Pipe cross-sectional area [m^2]
surface_area_rad = ( 4 * area_rad / Dh_rad) * L_rad;                        % [m^2] Pipe surface area
volume_rad = area_rad * L_rad;                                              % [m^3] Pipe volume
k_radiator = 1e-3;                                                          % [kg/(Pa*s)] Outlet flow contant
rho_rad = 2700;                                                             % [kg/m^3] Radiator material density
cp_rad = 910;                                                               % [J/(kg*K)] Radiator material specific heat
k_rad = 300;                                                                % [W/K/m^2] Convective heat transfer coefficient 
mass_rad = (air_primary_area_rad + air_area_fins_rad)* ...  
           t_wall_rad * rho_rad;                                            % [kg] Radiator mass


  

%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%  Battery  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

SOC_initial = 95;                                                           % [%] Battery initial state of charge

N_ser_batt = 1;                                                             % [-] N. of series batteries
N_par_batt = 1;                                                             % [-] N. of parallel batteries

E_single_battery = 20.48;                                                   % [kWh] Single battery energy stored
E_total_battery = E_single_battery*N_par_batt*N_ser_batt;                   % [kWh] Total energy stored

V_full_single = 476.77;                                                     % [V] Fully charged voltage
V_nom_single = 409.6;                                                       % [V] Nominal voltage
V_exp_single = 442.5;                                                       % [V] Exponential zone voltage     
V_full = V_full_single*N_ser_batt;                                          % [V] Total fully charged voltage 
V_nom = V_nom_single*N_ser_batt;                                            % [V] Total nominal voltage
V_exp = V_exp_single*N_ser_batt;                                            % [V] Total exponential zone voltage  

Lambda = 1.038999999968;                                                    % [-] Coulombic efficiency
Q_rated_single = 50;                                                        % [Ah] Rated capacity
Q_exp_single = 2.4656;                                                      % [Ah] Exponential zone capacity
Q_nom_single = 45.22;                                                       % [Ah] Capacity at nominal voltage     
Q_max_single=51.7;                                                          % [Ah] Maximum capacity
Q_rated = Q_rated_single*N_par_batt;                                        % [Ah] Total Rated capacity
Q_exp = Q_exp_single*N_par_batt;                                            % [Ah] Total exponential zone capacity
Q_nom = Q_nom_single*N_par_batt;                                            % [Ah] Total capacity at nominal voltage  
Q =Q_max_single*N_par_batt;                                                 % [Ah] Total maximum capacity

I_nom_single=21.74;                                                         % [A] Nominal discharge current
I_nom = I_nom_single*N_par_batt;                                            % [A] Total nominal discharge current

R_int_single = 0.082;                                                       % [Ohm] Internal resistance
R_int = R_int_single*N_ser_batt/N_par_batt;                                 % [Ohm] Total internal resistance

T_response = 0.001;                                                         % [s] Filtered current time constant

% Extraction of empirical parameters
A = V_full - V_exp;                                                         % [V] Exponential zone amplitude
V0 = V_full + R_int*I_nom - A;                                              % [V] Contant voltage
B_batt  = 3/Q_exp;                                                          % [Ah^-1] Exponential zone inverse time constant
K=(-V_exp+V0-R_int*I_nom+A.*exp(-3))*(Q-Q_exp)/(Q*(Q_exp+I_nom));           % [V/Ah] Polarization constant
it_initial = (1-SOC_initial/100)*Q/Lambda*3600; %[Ah]                       % [Ah] Initial exctracted capacity


%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%  Motor  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%


P_rated = 110000;                                                           % [W] Rated power
Va_rated = 520;                                                             % [V] Rated armature voltage 
eta_motor = 0.92;                                                           % [-] Motor efficiency
w_rated = 3220*2*pi/60;                                                     % [rad/s] Rated motor speed

Ia_rated = 224;                                                             % [A] Rated armature current
Te_rated = 326;                                                             % [Nm] Rated motor torque
Ra = 58.5e-3;                                                               % [Ohm] Armature resistance
La = 1.03e-3;                                                               % [H] Armature inductance 
J_m = 0.07;                                                                 % [kg*m^2] Rotor inertia
B_m = 0.01;                                                                 % [Nm/(rad/s)] Motor viscous friction coefficient 

Kt_m = Te_rated/Ia_rated;                                                   % [Nm/A] Motor torque constant
Ke_m = Kt_m;                                                                %[V/(rad/s)] Motor speed contant


% Motor control parameters

% s = speed control loop  c = current control loop

w_c = 1e3;                                                                  % [Hz] Current control loop frequency
w_s = w_c/5;                                                                % [Hz] Speed control loop frequency

Kpc = La*w_c;                                                               % [V/A] Proportional gain coefficient of current loop
Kic = Ra*w_c;                                                               % [V/(A*s)] Integral gain coefficient of current loop
Kac = 1/Kpc;                                                                % [A/V] Anti wind-up gain

Kps = J_m*5;                                                                % [kg*m^2] Proportional gain coefficient of speed loop 
Kis = J_m*w_s;                                                              % [kg*m^2/s] Integral gain coefficient of outer loop 

Kas = 1/Kps;                                                                % [1/(kg*m^2)] Anti wind-up gain


%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%  Buck-Boost converter  %%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

fsw_bb = 50e3;                                                              % [Hz] Switching frequency 

Vin_bb = 440;                                                               % [V] Nominal input voltage 
Vout_nom_bb = 520;                                                          % [V] Nominal output voltage

D_bb = Vout_nom_bb/(Vout_nom_bb+Vin_bb);                                    % [-] Nominal duty cycle
Io_nom_bb = Ia_rated;                                                       % [A] Nominal output current
i_L_bb = Io_nom_bb/(1-D_bb);                                                % [A] Nominal inductor current

Delta_i_L_bb = 0.2*i_L_bb;                                                  % [A] Inductor current ripples
Delta_v_bb = 0.002*Vout_nom_bb;                                             % [V] Output voltage ripples

L_bb = round(Vin_bb*D_bb/(Delta_i_L_bb*fsw_bb),1,"significant");            % [H] Input inductance
C_bb = round(Io_nom_bb*D_bb/(Delta_v_bb*fsw_bb),1,"significant");           % [F] Output capacitance

Kp_bb=0.01;                                                                  % [1/A] Proportional gain coefficient
Ki_bb=0.1;                                                                   % [1/As] Integral gain coefficient
Kaw_bb=1000;                                                                 % [A] Anti-windup gain coefficient



%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%  Boost converter  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

fsw_b = 50e3;                                                               % [Hz] Switching frequency 

Vin_b = 380;                                                                % [V] Nominal input voltage 
Vout_nom_b = 440;                                                           % [V] Nominal output voltage 

D_b = (Vout_nom_b-Vin_b)/Vout_nom_b;                                        % [-] Nominal duty cycle
i_L_nom_b = 197;                                                            % [A] Nominal input current
Io_b = i_L_nom_b*(1-D_b);                                                   % [A] Nominal output current

Delta_i_L_b = 0.2*i_L_nom_b;                                                % [A] Inductor current ripples
Delta_v_b = 0.002*Vout_nom_b;                                               % [V] Output voltage ripples

L_b = round(Vin_b*D_b*(1-D_b)/(Delta_i_L_b*fsw_b),1,"significant");         % [H] Input inductance
C_b = round(Io_b*D_b/(Delta_v_b*fsw_b),1,"significant");                    % [F] Output capacitance

Kp_b=0.01;                                                                  % [1/V] Proportional gain coefficient
Ki_b=0.1;                                                                   % [1/Vs] Integral gain coefficient
Kaw_b=1000;                                                                 % [V] Anti-windup gain coefficient



%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%  DC Bus  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%


R_bus=0.01;                                                                 % [Ohm] DC Bus wire resistance


%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  EMS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

SOC_high=80;                                                                % [%] EMS SOC upper limit
SOC_low=40;                                                                 % [%] EMS SOC lower limit
P_FC_opt=75e3;                                                              % [W] Fuel cell optimal output power


%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%  Input velocity  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

% Here, define the input of the model. It is a motor shaft reference
% velocity exoressed in [rad/s]

% Input_velocity=;                                                           % [rad/s] Motor shaft reference velocity


%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%  Simulation  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

% Simulation settings --> SolverType = 'Variable-step'; Solver = 'ode15s'; RelTol = 1e-3;

% out=sim('Propulsion_model.slx')


