%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%% Load Cycle Examples %%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%

addpath(genpath('Load Cycle Example'));

run('Propulsion_script.m')                                                  % Firstly, must be set the parameters of the model

load("Drive_cycle_input.mat");
load("Drive_cycle_input2.mat");


t_sim=1800;                                                                 %30 min of simulations
time_sim=linspace(0,t_sim,10000);


figure('Position',[300 200 1000 500],'units', 'normalized')
tiledlayout(1, 1, "TileSpacing", "tight",'Padding','compact')
nexttile
plot(Drive_Cycle_Input(:,1),Drive_Cycle_Input(:,2),'linewidth',1.5), hold on
ylim([0 350])
xlim([0 t_sim])
xticks(0:300:1800)
set(gcf, 'Color', 'w')
ylabel('velocity [rad/s]')
xlabel('time [s]')

figure('Position',[300 200 1000 500],'units', 'normalized')
tiledlayout(1, 1, "TileSpacing", "tight",'Padding','compact')
nexttile
plot(Drive_Cycle_Input2(:,1),Drive_Cycle_Input2(:,2),'linewidth',1.5), hold on
ylim([0 350])
xlim([0 t_sim])
xticks(0:300:1800)
set(gcf, 'Color', 'w')
ylabel('velocity [rad/s]')
xlabel('time [s]')



%%                                                                          %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% Simulations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                          %%


T_stop=t_sim;

I=1;                                                                        % I=1 simulate Drive_Cycle_Input1,  I=2 simulate Drive_Cycle_Input2

if I == 1

    Input_velocity=Drive_Cycle_Input;
    out=sim('Propulsion_model.slx')


elseif I == 2

    Input_velocity=Drive_Cycle_Input2;
    out2=sim('Propulsion_model.slx')

end






